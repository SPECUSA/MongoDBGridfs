CREATE TABLE postgres.public.filedata (
	filename char(200),
	blobdata bytea,
	metadata1 char(200),
	metadata2 char(200),
	metadata3 char(200),
	"id" char(200)
);
